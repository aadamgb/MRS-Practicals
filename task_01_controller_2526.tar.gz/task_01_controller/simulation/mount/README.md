# Singularity-host shared directory

This directory is going to be mounted into `/opt/mrs/host`.
